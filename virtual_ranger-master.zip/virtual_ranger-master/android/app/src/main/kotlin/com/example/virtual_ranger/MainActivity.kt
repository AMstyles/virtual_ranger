package com.example.virtual_ranger

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
