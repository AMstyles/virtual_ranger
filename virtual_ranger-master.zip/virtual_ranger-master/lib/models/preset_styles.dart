import 'package:flutter/material.dart';

const drawerTextStyle =
    TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w400);

const profTextStyle =
    TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold);

const drawerTextStyle2 =
    TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.w400);
