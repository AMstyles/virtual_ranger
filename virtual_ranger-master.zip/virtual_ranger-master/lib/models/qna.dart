class QnA {
  int sequence;
  String qna;
  late String question;
  late String answer;

  QnA({required this.sequence, required this.qna});
}
