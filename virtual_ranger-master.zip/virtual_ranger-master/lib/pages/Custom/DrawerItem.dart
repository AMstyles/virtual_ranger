import 'package:flutter/material.dart';

class DrawerItem {
  final String title;
  final IconData icon;
  int num;

  DrawerItem({required this.title, required this.icon, required this.num});
}
